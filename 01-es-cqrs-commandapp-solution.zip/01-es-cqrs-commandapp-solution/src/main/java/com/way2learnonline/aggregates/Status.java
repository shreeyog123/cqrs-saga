package com.way2learnonline.aggregates;

public enum Status {
    CREATED, ACTIVATED, HOLD
}

package com.way2learnonline.orderservice.aggregates;

public enum OrderStatus {
    CREATED, SHIPPED, REJECTED
}

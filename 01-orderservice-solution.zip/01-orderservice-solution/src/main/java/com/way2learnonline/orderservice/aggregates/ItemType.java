package com.way2learnonline.orderservice.aggregates;

public enum ItemType {

    LAPTOP, HEADPHONE, SMARTPHONE
}
